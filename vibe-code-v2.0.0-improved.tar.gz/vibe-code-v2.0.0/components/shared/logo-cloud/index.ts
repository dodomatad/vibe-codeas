export { default } from "./logo-cloud";
